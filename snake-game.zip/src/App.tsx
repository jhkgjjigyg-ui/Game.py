import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Position,
  Direction,
  GameStatus,
  GameDifficulty,
  GameMode,
  FoodItem,
  Obstacle,
  SnakeSkin,
  HighScoreEntry,
} from './types';
import {
  getSelectedSkin,
  setSelectedSkinId,
  getAllSkins,
  saveCustomSkin,
  deleteCustomSkin,
  getHighScores,
  saveHighScore,
} from './utils/storage';
import { soundManager } from './utils/audio';
import { Header } from './components/Header';
import { ScoreBoard } from './components/ScoreBoard';
import { SnakeCanvas } from './components/SnakeCanvas';
import { GameControls } from './components/GameControls';
import { SkinGallery } from './components/SkinGallery';
import { SkinCustomizer } from './components/SkinCustomizer';
import { Leaderboard } from './components/Leaderboard';

const GRID_SIZE = 22;

export default function App() {
  const [activeTab, setActiveTab] = useState<'game' | 'gallery' | 'customizer' | 'leaderboard'>('game');

  // Skins State
  const [allSkins, setAllSkins] = useState<SnakeSkin[]>([]);
  const [equippedSkin, setEquippedSkin] = useState<SnakeSkin>(getSelectedSkin());
  const [editingSkin, setEditingSkin] = useState<SnakeSkin | undefined>(undefined);

  // Sound Mute State
  const [isMuted, setIsMuted] = useState<boolean>(soundManager.settings.muted);

  // High Scores State
  const [highScores, setHighScores] = useState<HighScoreEntry[]>([]);

  // Game Settings State
  const [difficulty, setDifficulty] = useState<GameDifficulty>('MEDIUM');
  const [gameMode, setGameMode] = useState<GameMode>('CLASSIC');

  // Game Runtime State
  const [status, setStatus] = useState<GameStatus>('IDLE');
  const [snake, setSnake] = useState<Position[]>([]);
  const [direction, setDirection] = useState<Direction>('UP');
  const pendingDirectionRef = useRef<Direction>('UP');

  const [food, setFood] = useState<FoodItem | null>(null);
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);

  const [score, setScore] = useState<number>(0);
  const [combo, setCombo] = useState<number>(1);
  const [foodEaten, setFoodEaten] = useState<number>(0);

  const lastEatTimeRef = useRef<number>(0);

  // Initialize storage & sound
  useEffect(() => {
    soundManager.initSettings();
    setIsMuted(soundManager.settings.muted);
    setAllSkins(getAllSkins());
    setEquippedSkin(getSelectedSkin());
    setHighScores(getHighScores());
  }, []);

  // Helper to get speed interval in ms based on difficulty
  const getSpeedInterval = useCallback((diff: GameDifficulty): number => {
    switch (diff) {
      case 'EASY':
        return 160;
      case 'MEDIUM':
        return 115;
      case 'HARD':
        return 80;
      case 'INSANE':
        return 50;
      default:
        return 115;
    }
  }, []);

  // Generate random position on grid not overlapping snake or obstacles
  const getRandomPosition = useCallback((currentSnake: Position[], currentObstacles: Obstacle[]): Position => {
    let pos: Position;
    let collision = true;

    while (collision) {
      pos = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };

      const hitsSnake = currentSnake.some((s) => s.x === pos.x && s.y === pos.y);
      const hitsObstacle = currentObstacles.some((o) => o.x === pos.x && o.y === pos.y);

      if (!hitsSnake && !hitsObstacle) {
        collision = false;
        return pos;
      }
    }
    return { x: 5, y: 5 };
  }, []);

  // Spawn Food Item
  const spawnFood = useCallback((currentSnake: Position[], currentObstacles: Obstacle[], skin: SnakeSkin): FoodItem => {
    const pos = getRandomPosition(currentSnake, currentObstacles);
    const isGolden = Math.random() < 0.2; // 20% chance for golden food

    return {
      x: pos.x,
      y: pos.y,
      type: isGolden ? 'GOLDEN' : 'REGULAR',
      emoji: isGolden ? '⭐' : skin.foodSkin || '🍎',
      points: isGolden ? 30 : 10,
    };
  }, [getRandomPosition]);

  // Generate Obstacles if mode === 'OBSTACLES'
  const generateObstacles = useCallback((): Obstacle[] => {
    if (gameMode !== 'OBSTACLES') return [];
    const obsList: Obstacle[] = [];
    const count = 12;

    for (let i = 0; i < count; i++) {
      const x = Math.floor(Math.random() * (GRID_SIZE - 4)) + 2;
      const y = Math.floor(Math.random() * (GRID_SIZE - 4)) + 2;

      // Keep center start area free
      const nearCenter = Math.abs(x - 10) < 3 && Math.abs(y - 12) < 3;
      if (!nearCenter && !obsList.some((o) => o.x === x && o.y === y)) {
        obsList.push({ x, y });
      }
    }
    return obsList;
  }, [gameMode]);

  // Initialize new game board
  const resetGame = useCallback(() => {
    const initialSnake: Position[] = [
      { x: 10, y: 12 },
      { x: 10, y: 13 },
      { x: 10, y: 14 },
    ];
    const initialDir: Direction = 'UP';
    pendingDirectionRef.current = initialDir;

    const obs = generateObstacles();
    const newFood = spawnFood(initialSnake, obs, equippedSkin);

    setSnake(initialSnake);
    setDirection(initialDir);
    setObstacles(obs);
    setFood(newFood);
    setScore(0);
    setCombo(1);
    setFoodEaten(0);
    setStatus('PLAYING');
    soundManager.playButtonClick();
  }, [equippedSkin, generateObstacles, spawnFood]);

  // Handle Game Over
  const triggerGameOver = useCallback((finalScore: number, foodCount: number) => {
    setStatus('GAMEOVER');
    soundManager.playGameOverSound();

    if (finalScore > 0) {
      const today = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const updatedScores = saveHighScore({
        score: finalScore,
        date: today,
        skinName: equippedSkin.name,
        difficulty,
        mode: gameMode,
        foodEaten: foodCount,
      });
      setHighScores(updatedScores);
    }
  }, [equippedSkin, difficulty, gameMode]);

  // Game Tick Logic
  const tick = useCallback(() => {
    if (status !== 'PLAYING') return;

    setSnake((prevSnake) => {
      if (prevSnake.length === 0) return prevSnake;

      const currentDir = pendingDirectionRef.current;
      setDirection(currentDir);

      const head = prevSnake[0];
      let newHead: Position = { ...head };

      if (currentDir === 'UP') newHead.y -= 1;
      if (currentDir === 'DOWN') newHead.y += 1;
      if (currentDir === 'LEFT') newHead.x -= 1;
      if (currentDir === 'RIGHT') newHead.x += 1;

      // Handle Wall Collisions or Pass-Through
      if (gameMode === 'NO_WALLS') {
        if (newHead.x < 0) newHead.x = GRID_SIZE - 1;
        if (newHead.x >= GRID_SIZE) newHead.x = 0;
        if (newHead.y < 0) newHead.y = GRID_SIZE - 1;
        if (newHead.y >= GRID_SIZE) newHead.y = 0;
      } else {
        if (newHead.x < 0 || newHead.x >= GRID_SIZE || newHead.y < 0 || newHead.y >= GRID_SIZE) {
          triggerGameOver(score, foodEaten);
          return prevSnake;
        }
      }

      // Handle Self Collision (Ignore last tail segment if not growing)
      const isEating = food && newHead.x === food.x && newHead.y === food.y;
      const bodyCheckSegments = isEating ? prevSnake : prevSnake.slice(0, -1);
      const hitsSelf = bodyCheckSegments.some((seg) => seg.x === newHead.x && seg.y === newHead.y);

      if (hitsSelf) {
        triggerGameOver(score, foodEaten);
        return prevSnake;
      }

      // Handle Obstacle Collision
      const hitsObstacle = obstacles.some((obs) => obs.x === newHead.x && obs.y === newHead.y);
      if (hitsObstacle) {
        triggerGameOver(score, foodEaten);
        return prevSnake;
      }

      // Build new snake array
      const newSnake = [newHead, ...prevSnake];

      // Check Food Eat
      if (isEating && food) {
        soundManager.playEatSound(food.type === 'GOLDEN');

        // Combo Logic: Eat within 3 seconds increases combo
        const now = Date.now();
        let newCombo = combo;
        if (now - lastEatTimeRef.current < 3000) {
          newCombo = Math.min(5, combo + 1);
        } else {
          newCombo = 1;
        }
        lastEatTimeRef.current = now;
        setCombo(newCombo);

        const pts = food.points * newCombo;
        setScore((prev) => prev + pts);
        setFoodEaten((prev) => prev + 1);

        // Spawn next food
        setFood(spawnFood(newSnake, obstacles, equippedSkin));
      } else {
        // Pop tail if didn't eat
        newSnake.pop();
      }

      return newSnake;
    });
  }, [status, food, obstacles, gameMode, score, foodEaten, combo, equippedSkin, spawnFood, triggerGameOver]);

  // Main Game Loop Timer
  useEffect(() => {
    if (status !== 'PLAYING') return;

    const intervalMs = getSpeedInterval(difficulty);
    const timer = setInterval(() => {
      tick();
    }, intervalMs);

    return () => clearInterval(timer);
  }, [status, difficulty, getSpeedInterval, tick]);

  // Keyboard Event Handlers
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (activeTab !== 'game') return;

      const key = e.key;

      if (key === ' ' || key === 'p' || key === 'P') {
        e.preventDefault();
        if (status === 'PLAYING') setStatus('PAUSED');
        else if (status === 'PAUSED') setStatus('PLAYING');
        else if (status === 'IDLE' || status === 'GAMEOVER') resetGame();
        return;
      }

      if (key === 'r' || key === 'R') {
        e.preventDefault();
        resetGame();
        return;
      }

      if (status !== 'PLAYING') return;

      const currentDir = pendingDirectionRef.current;

      if ((key === 'ArrowUp' || key === 'w' || key === 'W') && currentDir !== 'DOWN') {
        e.preventDefault();
        pendingDirectionRef.current = 'UP';
      } else if ((key === 'ArrowDown' || key === 's' || key === 'S') && currentDir !== 'UP') {
        e.preventDefault();
        pendingDirectionRef.current = 'DOWN';
      } else if ((key === 'ArrowLeft' || key === 'a' || key === 'A') && currentDir !== 'RIGHT') {
        e.preventDefault();
        pendingDirectionRef.current = 'LEFT';
      } else if ((key === 'ArrowRight' || key === 'd' || key === 'D') && currentDir !== 'LEFT') {
        e.preventDefault();
        pendingDirectionRef.current = 'RIGHT';
      }
    },
    [status, activeTab, resetGame]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  // Handle Skin Actions
  const handleSelectSkin = (skinId: string) => {
    setSelectedSkinId(skinId);
    const selected = getSelectedSkin();
    setEquippedSkin(selected);

    if (status === 'PLAYING') {
      setStatus('PAUSED');
    }
  };

  const handleSaveCustomSkin = (newSkin: SnakeSkin, equipNow: boolean) => {
    const updatedCustomSkins = saveCustomSkin(newSkin);
    const freshAllSkins = getAllSkins();
    setAllSkins(freshAllSkins);

    if (equipNow) {
      handleSelectSkin(newSkin.id);
    }
    setActiveTab('gallery');
  };

  const handleDeleteSkin = (skinId: string) => {
    deleteCustomSkin(skinId);
    setAllSkins(getAllSkins());
    setEquippedSkin(getSelectedSkin());
  };

  const handleToggleMute = () => {
    const newMuted = !isMuted;
    soundManager.setMuted(newMuted);
    setIsMuted(newMuted);
  };

  const bestHighScore = highScores.length > 0 ? Math.max(...highScores.map((h) => h.score)) : 0;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top App Header */}
      <Header
        activeTab={activeTab}
        onTabChange={(tab) => {
          if (status === 'PLAYING') setStatus('PAUSED');
          setActiveTab(tab);
        }}
        equippedSkin={equippedSkin}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 flex flex-col justify-start">
        {/* TAB 1: Play Game */}
        {activeTab === 'game' && (
          <div className="flex flex-col items-center w-full my-auto">
            <ScoreBoard
              score={score}
              highScore={bestHighScore}
              foodEaten={foodEaten}
              combo={combo}
              difficulty={difficulty}
              gameMode={gameMode}
              skin={equippedSkin}
            />

            <SnakeCanvas
              snake={snake}
              direction={direction}
              food={food}
              obstacles={obstacles}
              skin={equippedSkin}
              status={status}
              gameMode={gameMode}
              score={score}
              highScore={bestHighScore}
              combo={combo}
              gridSize={GRID_SIZE}
              onRestart={resetGame}
              onResume={() => setStatus('PLAYING')}
              onOpenSkinGallery={() => setActiveTab('gallery')}
            />

            <div className="mt-4 w-full">
              <GameControls
                status={status}
                currentDirection={direction}
                difficulty={difficulty}
                gameMode={gameMode}
                onDirectionChange={(dir) => {
                  if (status === 'PLAYING') {
                    pendingDirectionRef.current = dir;
                  }
                }}
                onPauseToggle={() => {
                  if (status === 'PLAYING') setStatus('PAUSED');
                  else if (status === 'PAUSED') setStatus('PLAYING');
                  else if (status === 'IDLE' || status === 'GAMEOVER') resetGame();
                }}
                onRestart={resetGame}
                onDifficultyChange={(diff) => setDifficulty(diff)}
                onModeChange={(mode) => setGameMode(mode)}
              />
            </div>
          </div>
        )}

        {/* TAB 2: Skin Gallery / Wardrobe */}
        {activeTab === 'gallery' && (
          <SkinGallery
            skins={allSkins}
            selectedSkinId={equippedSkin.id}
            onSelectSkin={handleSelectSkin}
            onCreateNewSkin={() => {
              setEditingSkin(undefined);
              setActiveTab('customizer');
            }}
            onEditSkin={(skin) => {
              setEditingSkin(skin);
              setActiveTab('customizer');
            }}
            onDeleteSkin={handleDeleteSkin}
          />
        )}

        {/* TAB 3: Skin Customizer / Studio */}
        {activeTab === 'customizer' && (
          <SkinCustomizer
            initialSkin={editingSkin}
            onSave={handleSaveCustomSkin}
            onCancel={() => setActiveTab('gallery')}
          />
        )}

        {/* TAB 4: Records / Leaderboard */}
        {activeTab === 'leaderboard' && (
          <Leaderboard
            scores={highScores}
            onPlayAgain={() => {
              setActiveTab('game');
              resetGame();
            }}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-slate-900 py-3 px-4 text-center text-xs text-slate-500">
        SnakeCraft • Custom Skin Edition • Play, Design & Customize
      </footer>
    </div>
  );
}
