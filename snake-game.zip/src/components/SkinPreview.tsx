import React, { useEffect, useRef } from 'react';
import { SnakeSkin } from '../types';

interface SkinPreviewProps {
  skin: SnakeSkin;
  width?: number;
  height?: number;
  animated?: boolean;
  className?: string;
  showFood?: boolean;
}

export const SkinPreview: React.FC<SkinPreviewProps> = ({
  skin,
  width = 240,
  height = 140,
  animated = true,
  className = '',
  showFood = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Dark subtle grid background
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      const gridSize = 16;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Generate snake points along an animated wave path
      const numSegments = 10;
      const points: { x: number; y: number; angle: number }[] = [];
      const centerX = width * 0.48;
      const centerY = height * 0.52;
      const segmentRadius = 11;

      const phase = animated ? time * 0.05 : 0;

      for (let i = 0; i < numSegments; i++) {
        // S-curve formula
        const t = (i / (numSegments - 1)) * Math.PI * 1.5;
        const xOffset = (numSegments - 1 - i) * 16 - 60;
        const wave = Math.sin(t - phase) * 22;

        const x = centerX - xOffset;
        const y = centerY + wave;

        // Angle relative to next point
        let angle = 0;
        if (i > 0) {
          const prev = points[i - 1];
          angle = Math.atan2(prev.y - y, prev.x - x);
        }

        points.push({ x, y, angle });
      }

      // Fix head angle based on second segment
      if (points.length > 1) {
        points[0].angle = Math.atan2(points[0].y - points[1].y, points[0].x - points[1].x);
      }

      // Draw Glow if configured
      if (skin.glowColor && skin.glowColor !== 'none') {
        ctx.shadowColor = skin.glowColor;
        ctx.shadowBlur = 12;
      } else {
        ctx.shadowBlur = 0;
      }

      // Draw Body Segments from Tail (last) to Head (0)
      for (let i = points.length - 1; i >= 1; i--) {
        const p = points[i];
        const progress = i / (points.length - 1);
        const radius = segmentRadius * (1 - progress * 0.35); // Slight tail taper

        // Compute fill color according to pattern
        let fillStyle: string | CanvasGradient = skin.bodyStartColor;

        if (skin.pattern === 'GRADIENT') {
          fillStyle = interpolateColor(skin.bodyStartColor, skin.bodyEndColor, progress);
        } else if (skin.pattern === 'STRIPES') {
          fillStyle = i % 2 === 0 ? skin.bodyStartColor : skin.bodyEndColor;
        } else if (skin.pattern === 'RAINBOW') {
          const hue = (time * 2 + i * 35) % 360;
          fillStyle = `hsl(${hue}, 90%, 60%)`;
        } else if (skin.pattern === 'NEON') {
          fillStyle = i % 3 === 0 ? skin.headColor : i % 2 === 0 ? skin.bodyStartColor : skin.bodyEndColor;
        } else if (skin.pattern === 'CHECKER') {
          fillStyle = i % 2 === 0 ? skin.bodyStartColor : skin.borderColor;
        } else {
          fillStyle = skin.bodyStartColor;
        }

        ctx.fillStyle = fillStyle;
        ctx.strokeStyle = skin.borderColor || '#000000';
        ctx.lineWidth = 2;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.angle);

        // Draw shape based on skin.bodyShape
        if (skin.bodyShape === 'SQUARE') {
          ctx.beginPath();
          ctx.rect(-radius, -radius, radius * 2, radius * 2);
          ctx.fill();
          ctx.stroke();
        } else if (skin.bodyShape === 'HEXAGON') {
          drawPolygon(ctx, 0, 0, radius * 1.1, 6);
          ctx.fill();
          ctx.stroke();
        } else if (skin.bodyShape === 'SPIKY') {
          drawStar(ctx, 0, 0, 4, radius * 1.3, radius * 0.7);
          ctx.fill();
          ctx.stroke();
        } else {
          // Default ROUNDED
          ctx.beginPath();
          ctx.arc(0, 0, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Polka dot pattern overlay
          if (skin.pattern === 'POLKA') {
            ctx.fillStyle = skin.borderColor || '#FFFFFF';
            ctx.beginPath();
            ctx.arc(0, 0, radius * 0.35, 0, Math.PI * 2);
            ctx.fill();
          } else if (skin.pattern === 'SCALES') {
            ctx.strokeStyle = skin.borderColor || 'rgba(0,0,0,0.3)';
            ctx.beginPath();
            ctx.arc(-radius * 0.2, 0, radius * 0.6, 0, Math.PI);
            ctx.stroke();
          }
        }

        ctx.restore();
      }

      // Reset shadow for details
      ctx.shadowBlur = 0;

      // Draw Head (Point 0)
      const head = points[0];
      const headRadius = segmentRadius * 1.25;

      ctx.save();
      ctx.translate(head.x, head.y);
      ctx.rotate(head.angle);

      // Head Base
      ctx.fillStyle = skin.headColor;
      ctx.strokeStyle = skin.borderColor || '#000000';
      ctx.lineWidth = 2.5;

      if (skin.glowColor) {
        ctx.shadowColor = skin.glowColor;
        ctx.shadowBlur = 10;
      }

      ctx.beginPath();
      ctx.arc(0, 0, headRadius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      ctx.shadowBlur = 0; // Turn off glow for eyes/accessories

      // Draw Eyes and Head Accessories based on headStyle
      drawHeadDetails(ctx, headRadius, skin);

      ctx.restore();

      // Draw Food beside the snake head
      if (showFood) {
        const foodX = width * 0.82;
        const foodY = height * 0.45 + Math.sin(time * 0.08) * 4;

        ctx.font = '24px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(skin.foodSkin || '🍎', foodX, foodY);
      }

      if (animated) {
        time++;
        animationFrameId = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [skin, width, height, animated, showFood]);

  return (
    <div className={`relative overflow-hidden rounded-xl border border-slate-700/60 bg-slate-900 shadow-inner ${className}`}>
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        className="block w-full h-full object-cover"
      />
    </div>
  );
};

// Helper function to draw head eyes, visor, crown, etc.
function drawHeadDetails(ctx: CanvasRenderingContext2D, r: number, skin: SnakeSkin) {
  const eyeOffset = r * 0.45;
  const eyeRadius = r * 0.28;

  switch (skin.headStyle) {
    case 'CUTE_EYES':
      // Big cute anime eyes with white sparkle
      [-eyeOffset, eyeOffset].forEach((y) => {
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(r * 0.2, y, eyeRadius * 1.1, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(r * 0.3, y - 2, eyeRadius * 0.4, 0, Math.PI * 2);
        ctx.fill();
      });
      break;

    case 'CYBER_VISOR':
      // Cyberpunk visor visor bar
      ctx.fillStyle = skin.eyeColor || '#00FFFF';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(r * 0.1, -r * 0.7, r * 0.5, r * 1.4, 3);
      ctx.fill();
      ctx.stroke();

      // Glint on visor
      ctx.fillStyle = 'rgba(255,255,255,0.7)';
      ctx.fillRect(r * 0.2, -r * 0.5, r * 0.2, r * 0.3);
      break;

    case 'SUNGLASSES':
      // Cool black shades
      ctx.fillStyle = '#1E293B';
      ctx.beginPath();
      ctx.roundRect(0, -r * 0.75, r * 0.6, r * 0.65, 2);
      ctx.roundRect(0, 0.1, r * 0.6, r * 0.65, 2);
      ctx.fill();

      // Bridge
      ctx.strokeStyle = '#1E293B';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(r * 0.2, -r * 0.1);
      ctx.lineTo(r * 0.2, r * 0.1);
      ctx.stroke();

      // Lens shine
      ctx.fillStyle = '#94A3B8';
      ctx.beginPath();
      ctx.moveTo(r * 0.1, -r * 0.6);
      ctx.lineTo(r * 0.4, -r * 0.3);
      ctx.lineTo(r * 0.3, -r * 0.3);
      ctx.fill();
      break;

    case 'CROWN':
      // Normal eyes
      drawDefaultEyes(ctx, r, skin.eyeColor);

      // Gold Crown on head top
      ctx.fillStyle = '#F59E0B';
      ctx.strokeStyle = '#78350F';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-r * 0.5, -r * 0.6);
      ctx.lineTo(-r * 0.2, -r * 1.3);
      ctx.lineTo(0, -r * 0.7);
      ctx.lineTo(r * 0.2, -r * 1.3);
      ctx.lineTo(r * 0.5, -r * 0.6);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Jewels
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(0, -r * 0.8, 2, 0, Math.PI * 2);
      ctx.fill();
      break;

    case 'HORNS':
      drawDefaultEyes(ctx, r, skin.eyeColor);

      // Demon/Cosmic horns
      ctx.fillStyle = skin.borderColor || '#818CF8';
      [-1, 1].forEach((dir) => {
        ctx.beginPath();
        ctx.moveTo(-r * 0.2, dir * r * 0.6);
        ctx.quadraticCurveTo(-r * 0.9, dir * r * 1.4, -r * 0.1, dir * r * 1.2);
        ctx.fill();
      });
      break;

    case 'CAT_EARS':
      drawDefaultEyes(ctx, r, skin.eyeColor);

      // Cute Pink/Soft cat ears
      ctx.fillStyle = skin.bodyStartColor || '#F472B6';
      [-1, 1].forEach((dir) => {
        ctx.beginPath();
        ctx.moveTo(-r * 0.4, dir * r * 0.5);
        ctx.lineTo(-r * 0.8, dir * r * 1.3);
        ctx.lineTo(r * 0.1, dir * r * 0.8);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#FCE7F3';
        ctx.beginPath();
        ctx.moveTo(-r * 0.4, dir * r * 0.6);
        ctx.lineTo(-r * 0.65, dir * r * 1.1);
        ctx.lineTo(-0.05, dir * r * 0.8);
        ctx.closePath();
        ctx.fill();
      });
      break;

    case 'DRAGON':
      // Piercing dragon slit eyes
      [-eyeOffset, eyeOffset].forEach((y) => {
        ctx.fillStyle = skin.eyeColor || '#FACC15';
        ctx.beginPath();
        ctx.arc(r * 0.2, y, eyeRadius, 0, Math.PI * 2);
        ctx.fill();

        // Slit pupil
        ctx.fillStyle = '#000000';
        ctx.fillRect(r * 0.18, y - eyeRadius * 0.8, 2, eyeRadius * 1.6);
      });

      // Spikes on head
      ctx.fillStyle = '#DC2626';
      ctx.beginPath();
      ctx.moveTo(-r * 0.8, 0);
      ctx.lineTo(-r * 1.4, 0);
      ctx.lineTo(-r * 0.6, -r * 0.3);
      ctx.fill();
      break;

    case 'SKELETON':
      // Dark hollow eye sockets
      [-eyeOffset, eyeOffset].forEach((y) => {
        ctx.fillStyle = '#0F172A';
        ctx.beginPath();
        ctx.arc(r * 0.2, y, eyeRadius * 1.2, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = skin.eyeColor || '#EF4444';
        ctx.beginPath();
        ctx.arc(r * 0.25, y, eyeRadius * 0.5, 0, Math.PI * 2);
        ctx.fill();
      });
      break;

    case 'CLASSIC':
    default:
      drawDefaultEyes(ctx, r, skin.eyeColor);
      break;
  }
}

function drawDefaultEyes(ctx: CanvasRenderingContext2D, r: number, eyeColor: string) {
  const eyeOffset = r * 0.45;
  const eyeRadius = r * 0.25;

  [-eyeOffset, eyeOffset].forEach((y) => {
    // White eye base
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(r * 0.2, y, eyeRadius, 0, Math.PI * 2);
    ctx.fill();

    // Pupil
    ctx.fillStyle = eyeColor || '#000000';
    ctx.beginPath();
    ctx.arc(r * 0.3, y, eyeRadius * 0.5, 0, Math.PI * 2);
    ctx.fill();
  });
}

// Helpers
function interpolateColor(color1: string, color2: string, factor: number): string {
  try {
    const c1 = hexToRgb(color1);
    const c2 = hexToRgb(color2);
    if (!c1 || !c2) return color1;

    const r = Math.round(c1.r + factor * (c2.r - c1.r));
    const g = Math.round(c1.g + factor * (c2.g - c1.g));
    const b = Math.round(c1.b + factor * (c2.b - c1.b));

    return `rgb(${r}, ${g}, ${b})`;
  } catch {
    return color1;
  }
}

function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : null;
}

function drawPolygon(ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, sides: number) {
  ctx.beginPath();
  for (let i = 0; i < sides; i++) {
    const angle = (i * 2 * Math.PI) / sides;
    const px = x + radius * Math.cos(angle);
    const py = y + radius * Math.sin(angle);
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

function drawStar(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  spikes: number,
  outerRadius: number,
  innerRadius: number
) {
  let rot = (Math.PI / 2) * 3;
  let x = cx;
  let y = cy;
  const step = Math.PI / spikes;

  ctx.beginPath();
  ctx.moveTo(cx, cy - outerRadius);
  for (let i = 0; i < spikes; i++) {
    x = cx + Math.cos(rot) * outerRadius;
    y = cy + Math.sin(rot) * outerRadius;
    ctx.lineTo(x, y);
    rot += step;

    x = cx + Math.cos(rot) * innerRadius;
    y = cy + Math.sin(rot) * innerRadius;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.lineTo(cx, cy - outerRadius);
  ctx.closePath();
}
