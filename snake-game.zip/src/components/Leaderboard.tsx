import React from 'react';
import { HighScoreEntry } from '../types';
import { Trophy, Medal, Flame, Calendar, Gamepad } from 'lucide-react';

interface LeaderboardProps {
  scores: HighScoreEntry[];
  onPlayAgain: () => void;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ scores, onPlayAgain }) => {
  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl text-slate-100">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-2xl font-black text-amber-400 flex items-center gap-2">
              <Trophy className="w-7 h-7 text-amber-400" /> High Score Records
            </h2>
            <p className="text-slate-400 text-xs sm:text-sm mt-1">
              Top slither performances saved locally on this browser.
            </p>
          </div>

          <button
            onClick={onPlayAgain}
            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold rounded-xl text-xs transition cursor-pointer self-start sm:self-auto flex items-center gap-2 shadow-lg"
          >
            <Gamepad className="w-4 h-4" /> Start New Game
          </button>
        </div>

        {scores.length === 0 ? (
          <div className="bg-slate-950/60 rounded-xl p-10 text-center border border-slate-800/80">
            <Trophy className="w-12 h-12 text-slate-700 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-300">No records yet!</h3>
            <p className="text-slate-500 text-xs mt-1">Play a game and set your first record score!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {scores.map((entry, index) => {
              const isTop1 = index === 0;
              const isTop2 = index === 1;
              const isTop3 = index === 2;

              return (
                <div
                  key={entry.id}
                  className={`flex items-center justify-between p-3.5 rounded-xl border transition ${
                    isTop1
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                      : isTop2
                      ? 'bg-slate-800/80 border-slate-700 text-slate-200'
                      : isTop3
                      ? 'bg-amber-800/20 border-amber-800/40 text-amber-300'
                      : 'bg-slate-950/60 border-slate-800/80 text-slate-400'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm">
                      {isTop1 ? (
                        <Medal className="w-6 h-6 text-amber-400" />
                      ) : isTop2 ? (
                        <Medal className="w-6 h-6 text-slate-300" />
                      ) : isTop3 ? (
                        <Medal className="w-6 h-6 text-amber-600" />
                      ) : (
                        <span className="text-slate-500 font-mono">#{index + 1}</span>
                      )}
                    </div>

                    <div>
                      <div className="font-extrabold text-sm flex items-center gap-2 text-slate-100">
                        <span>{entry.skinName}</span>
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.2 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                          {entry.difficulty}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> {entry.date}
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Flame className="w-3 h-3 text-orange-400" /> {entry.foodEaten} food eaten
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xl font-black text-emerald-400 font-mono tracking-tight">
                      {entry.score}
                    </div>
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">
                      {entry.mode}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
