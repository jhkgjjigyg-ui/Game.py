import React, { useEffect, useRef, useState } from 'react';
import {
  Position,
  SnakeSkin,
  FoodItem,
  Obstacle,
  Particle,
  GameStatus,
  GameMode,
  Direction,
} from '../types';

interface SnakeCanvasProps {
  snake: Position[];
  direction: Direction;
  food: FoodItem | null;
  obstacles: Obstacle[];
  skin: SnakeSkin;
  status: GameStatus;
  gameMode: GameMode;
  score: number;
  highScore: number;
  combo: number;
  gridSize?: number; // e.g. 20
  onRestart: () => void;
  onResume: () => void;
  onOpenSkinGallery: () => void;
}

export const SnakeCanvas: React.FC<SnakeCanvasProps> = ({
  snake,
  direction,
  food,
  obstacles,
  skin,
  status,
  gameMode,
  score,
  highScore,
  combo,
  gridSize = 22,
  onRestart,
  onResume,
  onOpenSkinGallery,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Particles for food eating burst
  const particlesRef = useRef<Particle[]>([]);
  // Floating text popups (+100, Combo x2)
  const popupsRef = useRef<{ id: number; text: string; x: number; y: number; alpha: number; color: string }[]>([]);
  const prevFoodRef = useRef<FoodItem | null>(null);

  const [canvasDimensions, setCanvasDimensions] = useState({ width: 500, height: 500 });

  // Handle responsive resizing
  useEffect(() => {
    const handleResize = () => {
      if (!containerRef.current) return;
      const size = Math.min(containerRef.current.clientWidth, window.innerHeight * 0.65);
      const alignedSize = Math.floor(size / gridSize) * gridSize;
      setCanvasDimensions({ width: Math.max(320, alignedSize), height: Math.max(320, alignedSize) });
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [gridSize]);

  // Detect food eating for particle bursts
  useEffect(() => {
    if (prevFoodRef.current && (!food || prevFoodRef.current.x !== food.x || prevFoodRef.current.y !== food.y)) {
      // Food was eaten! Spawn particles at old food pos
      const cellSize = canvasDimensions.width / gridSize;
      const fx = (prevFoodRef.current.x + 0.5) * cellSize;
      const fy = (prevFoodRef.current.y + 0.5) * cellSize;

      const pCount = 20;
      const newParticles: Particle[] = [];
      const particleColors = [skin.headColor, skin.glowColor || '#FBBF24', '#FFFFFF', '#EC4899', '#38BDF8'];

      for (let i = 0; i < pCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 1.5 + Math.random() * 4.5;
        newParticles.push({
          x: fx,
          y: fy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 2 + Math.random() * 5,
          color: particleColors[Math.floor(Math.random() * particleColors.length)],
          alpha: 1,
          life: 0,
          maxLife: 25 + Math.random() * 15,
        });
      }
      particlesRef.current.push(...newParticles);

      // Add floating score text
      const pts = prevFoodRef.current.points || 10;
      const comboText = combo > 1 ? ` +${pts} (x${combo} COMBO!)` : ` +${pts}`;
      popupsRef.current.push({
        id: Date.now() + Math.random(),
        text: comboText,
        x: fx,
        y: fy - 10,
        alpha: 1,
        color: combo > 1 ? '#F59E0B' : '#10B981',
      });
    }
    prevFoodRef.current = food;
  }, [food, combo, skin, canvasDimensions, gridSize]);

  // Main Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const width = canvasDimensions.width;
    const height = canvasDimensions.height;
    const cellSize = width / gridSize;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // 1. Grid Background
      ctx.fillStyle = '#0F172A';
      ctx.fillRect(0, 0, width, height);

      // Checkerboard tiles
      ctx.fillStyle = '#1E293B';
      for (let r = 0; r < gridSize; r++) {
        for (let c = 0; c < gridSize; c++) {
          if ((r + c) % 2 === 0) {
            ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
          }
        }
      }

      // Grid Lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= gridSize; i++) {
        ctx.beginPath();
        ctx.moveTo(i * cellSize, 0);
        ctx.lineTo(i * cellSize, height);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(0, i * cellSize);
        ctx.lineTo(width, i * cellSize);
        ctx.stroke();
      }

      // 2. Render Obstacles
      if (obstacles.length > 0) {
        obstacles.forEach((obs) => {
          ctx.fillStyle = '#475569';
          ctx.strokeStyle = '#0F172A';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.roundRect(
            obs.x * cellSize + 2,
            obs.y * cellSize + 2,
            cellSize - 4,
            cellSize - 4,
            4
          );
          ctx.fill();
          ctx.stroke();

          // Obstacle cross pattern
          ctx.strokeStyle = '#94A3B8';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(obs.x * cellSize + 6, obs.y * cellSize + 6);
          ctx.lineTo((obs.x + 1) * cellSize - 6, (obs.y + 1) * cellSize - 6);
          ctx.moveTo((obs.x + 1) * cellSize - 6, obs.y * cellSize + 6);
          ctx.lineTo(obs.x * cellSize + 6, (obs.y + 1) * cellSize - 6);
          ctx.stroke();
        });
      }

      // 3. Render Trail Effects
      if (skin.trailEffect && skin.trailEffect !== 'NONE' && snake.length > 0) {
        drawTrailEffects(ctx, snake, cellSize, skin.trailEffect, skin);
      }

      // 4. Render Food Item
      if (food) {
        const fx = (food.x + 0.5) * cellSize;
        const fy = (food.y + 0.5) * cellSize;

        // Food pulse
        const pulse = Math.sin(Date.now() * 0.008) * 0.15 + 1;

        // Glow
        ctx.shadowColor = food.type === 'GOLDEN' ? '#FBBF24' : '#EF4444';
        ctx.shadowBlur = 12 * pulse;

        ctx.font = `${cellSize * 0.75 * pulse}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(food.emoji || skin.foodSkin || '🍎', fx, fy);

        ctx.shadowBlur = 0;
      }

      // 5. Render Snake Body
      if (snake.length > 0) {
        // Body Glow
        if (skin.glowColor) {
          ctx.shadowColor = skin.glowColor;
          ctx.shadowBlur = 10;
        }

        for (let i = snake.length - 1; i >= 1; i--) {
          const seg = snake[i];
          const progress = i / (snake.length - 1);
          const px = seg.x * cellSize + cellSize / 2;
          const py = seg.y * cellSize + cellSize / 2;
          const radius = (cellSize / 2 - 1) * (1 - progress * 0.25);

          // Calculate fill style
          let fillStyle: string = skin.bodyStartColor;
          if (skin.pattern === 'GRADIENT') {
            fillStyle = interpolateColor(skin.bodyStartColor, skin.bodyEndColor, progress);
          } else if (skin.pattern === 'STRIPES') {
            fillStyle = i % 2 === 0 ? skin.bodyStartColor : skin.bodyEndColor;
          } else if (skin.pattern === 'RAINBOW') {
            const hue = (Date.now() * 0.1 + i * 20) % 360;
            fillStyle = `hsl(${hue}, 85%, 55%)`;
          } else if (skin.pattern === 'NEON') {
            fillStyle = i % 3 === 0 ? skin.headColor : skin.bodyStartColor;
          } else if (skin.pattern === 'CHECKER') {
            fillStyle = i % 2 === 0 ? skin.bodyStartColor : skin.borderColor;
          }

          ctx.fillStyle = fillStyle;
          ctx.strokeStyle = skin.borderColor || '#000000';
          ctx.lineWidth = 1.8;

          ctx.save();
          ctx.translate(px, py);

          if (skin.bodyShape === 'SQUARE') {
            ctx.fillRect(-radius, -radius, radius * 2, radius * 2);
            ctx.strokeRect(-radius, -radius, radius * 2, radius * 2);
          } else if (skin.bodyShape === 'HEXAGON') {
            drawPolygon(ctx, 0, 0, radius, 6);
            ctx.fill();
            ctx.stroke();
          } else if (skin.bodyShape === 'SPIKY') {
            drawStar(ctx, 0, 0, 4, radius * 1.2, radius * 0.6);
            ctx.fill();
            ctx.stroke();
          } else {
            // Default ROUNDED
            ctx.beginPath();
            ctx.arc(0, 0, radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            if (skin.pattern === 'POLKA') {
              ctx.fillStyle = skin.borderColor || '#FFFFFF';
              ctx.beginPath();
              ctx.arc(0, 0, radius * 0.3, 0, Math.PI * 2);
              ctx.fill();
            }
          }

          ctx.restore();
        }

        ctx.shadowBlur = 0; // Turn off glow for head details

        // 6. Render Snake Head
        const head = snake[0];
        const hx = head.x * cellSize + cellSize / 2;
        const hy = head.y * cellSize + cellSize / 2;
        const headRadius = cellSize / 2 - 1;

        let angle = 0;
        if (direction === 'RIGHT') angle = 0;
        if (direction === 'DOWN') angle = Math.PI / 2;
        if (direction === 'LEFT') angle = Math.PI;
        if (direction === 'UP') angle = -Math.PI / 2;

        ctx.save();
        ctx.translate(hx, hy);
        ctx.rotate(angle);

        // Head Glow
        if (skin.glowColor) {
          ctx.shadowColor = skin.glowColor;
          ctx.shadowBlur = 12;
        }

        // Head Base Circle
        ctx.fillStyle = skin.headColor;
        ctx.strokeStyle = skin.borderColor || '#000000';
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.arc(0, 0, headRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.shadowBlur = 0;

        // Draw eyes & accessories
        drawSnakeHeadDetails(ctx, headRadius, skin);

        ctx.restore();
      }

      // 7. Update & Draw Particles
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life++;
        p.alpha = 1 - p.life / p.maxLife;

        if (p.life >= p.maxLife) {
          particlesRef.current.splice(i, 1);
          continue;
        }

        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }

      // 8. Update & Draw Popups
      for (let i = popupsRef.current.length - 1; i >= 0; i--) {
        const pop = popupsRef.current[i];
        pop.y -= 0.8;
        pop.alpha -= 0.02;

        if (pop.alpha <= 0) {
          popupsRef.current.splice(i, 1);
          continue;
        }

        ctx.fillStyle = pop.color;
        ctx.globalAlpha = Math.max(0, pop.alpha);
        ctx.font = 'bold 15px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(pop.text, pop.x, pop.y);
        ctx.globalAlpha = 1;
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [snake, direction, food, obstacles, skin, canvasDimensions, gridSize]);

  return (
    <div
      ref={containerRef}
      className="relative flex flex-col items-center justify-center w-full max-w-xl mx-auto"
    >
      <div className="relative rounded-2xl overflow-hidden border-2 border-slate-700 bg-slate-900 shadow-2xl p-2">
        <canvas
          ref={canvasRef}
          width={canvasDimensions.width}
          height={canvasDimensions.height}
          className="block rounded-lg touch-none"
        />

        {/* Overlay: Game Idle */}
        {status === 'IDLE' && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="text-4xl mb-2 animate-bounce">{skin.foodSkin || '🍎'}</div>
            <h2 className="text-3xl font-extrabold text-white mb-2 tracking-wide">Ready to Slither?</h2>
            <p className="text-slate-300 text-sm mb-6 max-w-xs">
              Use <span className="text-emerald-400 font-semibold">Arrow Keys</span>, <span className="text-emerald-400 font-semibold">WASD</span> or on-screen controls to eat food and grow your length!
            </p>
            <div className="flex flex-wrap gap-3 justify-center">
              <button
                onClick={onRestart}
                className="px-6 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl shadow-lg transition transform hover:scale-105 active:scale-95 cursor-pointer"
              >
                Start Game
              </button>
              <button
                onClick={onOpenSkinGallery}
                className="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl border border-slate-600 transition cursor-pointer"
              >
                Choose Skin
              </button>
            </div>
          </div>
        )}

        {/* Overlay: Game Paused */}
        {status === 'PAUSED' && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20">
            <h2 className="text-3xl font-extrabold text-amber-400 mb-2">GAME PAUSED</h2>
            <p className="text-slate-300 text-sm mb-6">Take a break! Resume whenever you are ready.</p>
            <div className="flex flex-col gap-3 w-48">
              <button
                onClick={onResume}
                className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl shadow-md transition cursor-pointer"
              >
                Resume
              </button>
              <button
                onClick={onRestart}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-xl border border-slate-600 transition cursor-pointer"
              >
                Restart Game
              </button>
            </div>
          </div>
        )}

        {/* Overlay: Game Over */}
        {status === 'GAMEOVER' && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="text-5xl mb-2 animate-pulse">💥</div>
            <h2 className="text-3xl font-black text-red-500 mb-1">GAME OVER</h2>
            <p className="text-slate-400 text-xs uppercase tracking-widest mb-4">You crashed!</p>

            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-4 w-64 mb-6 shadow-inner">
              <div className="flex justify-between items-center mb-2 text-sm">
                <span className="text-slate-400">Final Score:</span>
                <span className="text-2xl font-black text-emerald-400">{score}</span>
              </div>
              <div className="flex justify-between items-center text-xs text-slate-400">
                <span>Best Record:</span>
                <span className="font-bold text-amber-400">{highScore}</span>
              </div>
              <div className="mt-2 pt-2 border-t border-slate-700 text-xs text-slate-400 flex justify-between">
                <span>Skin Used:</span>
                <span className="text-slate-200 font-medium">{skin.name}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 justify-center">
              <button
                onClick={onRestart}
                className="px-6 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold rounded-xl shadow-lg transition transform hover:scale-105 active:scale-95 cursor-pointer"
              >
                Play Again
              </button>
              <button
                onClick={onOpenSkinGallery}
                className="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl border border-slate-600 transition cursor-pointer"
              >
                Switch Skin
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper to draw head details (Eyes/Accessories) in actual game
function drawSnakeHeadDetails(ctx: CanvasRenderingContext2D, r: number, skin: SnakeSkin) {
  const eyeOffset = r * 0.45;
  const eyeRadius = r * 0.28;

  switch (skin.headStyle) {
    case 'CUTE_EYES':
      [-eyeOffset, eyeOffset].forEach((y) => {
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(r * 0.2, y, eyeRadius * 1.1, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(r * 0.3, y - 2, eyeRadius * 0.4, 0, Math.PI * 2);
        ctx.fill();
      });
      break;

    case 'CYBER_VISOR':
      ctx.fillStyle = skin.eyeColor || '#00FFFF';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(r * 0.1, -r * 0.7, r * 0.5, r * 1.4, 3);
      ctx.fill();
      ctx.stroke();
      break;

    case 'SUNGLASSES':
      ctx.fillStyle = '#1E293B';
      ctx.beginPath();
      ctx.roundRect(0, -r * 0.75, r * 0.6, r * 0.65, 2);
      ctx.roundRect(0, 0.1, r * 0.6, r * 0.65, 2);
      ctx.fill();
      break;

    case 'CROWN':
      drawGameDefaultEyes(ctx, r, skin.eyeColor);
      ctx.fillStyle = '#F59E0B';
      ctx.strokeStyle = '#78350F';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(-r * 0.5, -r * 0.6);
      ctx.lineTo(-r * 0.2, -r * 1.3);
      ctx.lineTo(0, -r * 0.7);
      ctx.lineTo(r * 0.2, -r * 1.3);
      ctx.lineTo(r * 0.5, -r * 0.6);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      break;

    case 'HORNS':
      drawGameDefaultEyes(ctx, r, skin.eyeColor);
      ctx.fillStyle = skin.borderColor || '#818CF8';
      [-1, 1].forEach((dir) => {
        ctx.beginPath();
        ctx.moveTo(-r * 0.2, dir * r * 0.6);
        ctx.quadraticCurveTo(-r * 0.9, dir * r * 1.4, -r * 0.1, dir * r * 1.2);
        ctx.fill();
      });
      break;

    case 'CAT_EARS':
      drawGameDefaultEyes(ctx, r, skin.eyeColor);
      ctx.fillStyle = skin.bodyStartColor || '#F472B6';
      [-1, 1].forEach((dir) => {
        ctx.beginPath();
        ctx.moveTo(-r * 0.4, dir * r * 0.5);
        ctx.lineTo(-r * 0.8, dir * r * 1.3);
        ctx.lineTo(r * 0.1, dir * r * 0.8);
        ctx.closePath();
        ctx.fill();
      });
      break;

    case 'DRAGON':
      [-eyeOffset, eyeOffset].forEach((y) => {
        ctx.fillStyle = skin.eyeColor || '#FACC15';
        ctx.beginPath();
        ctx.arc(r * 0.2, y, eyeRadius, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#000000';
        ctx.fillRect(r * 0.18, y - eyeRadius * 0.8, 2, eyeRadius * 1.6);
      });
      break;

    case 'SKELETON':
      [-eyeOffset, eyeOffset].forEach((y) => {
        ctx.fillStyle = '#0F172A';
        ctx.beginPath();
        ctx.arc(r * 0.2, y, eyeRadius * 1.2, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = skin.eyeColor || '#EF4444';
        ctx.beginPath();
        ctx.arc(r * 0.25, y, eyeRadius * 0.5, 0, Math.PI * 2);
        ctx.fill();
      });
      break;

    case 'CLASSIC':
    default:
      drawGameDefaultEyes(ctx, r, skin.eyeColor);
      break;
  }
}

function drawGameDefaultEyes(ctx: CanvasRenderingContext2D, r: number, eyeColor: string) {
  const eyeOffset = r * 0.45;
  const eyeRadius = r * 0.25;

  [-eyeOffset, eyeOffset].forEach((y) => {
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(r * 0.2, y, eyeRadius, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = eyeColor || '#000000';
    ctx.beginPath();
    ctx.arc(r * 0.3, y, eyeRadius * 0.5, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawTrailEffects(
  ctx: CanvasRenderingContext2D,
  snake: Position[],
  cellSize: number,
  trail: string,
  skin: SnakeSkin
) {
  const tail = snake[snake.length - 1];
  if (!tail) return;

  const tx = (tail.x + 0.5) * cellSize;
  const ty = (tail.y + 0.5) * cellSize;

  ctx.save();
  if (trail === 'SPARKLES') {
    ctx.fillStyle = skin.glowColor || '#FBBF24';
    for (let i = 0; i < 4; i++) {
      const offsetX = (Math.random() - 0.5) * cellSize;
      const offsetY = (Math.random() - 0.5) * cellSize;
      ctx.beginPath();
      ctx.arc(tx + offsetX, ty + offsetY, 2, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (trail === 'FIRE') {
    ctx.fillStyle = Math.random() > 0.5 ? '#F97316' : '#EF4444';
    ctx.beginPath();
    ctx.arc(tx, ty, cellSize * 0.4, 0, Math.PI * 2);
    ctx.fill();
  } else if (trail === 'BUBBLES') {
    ctx.strokeStyle = '#38BDF8';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(tx + (Math.random() - 0.5) * 8, ty + (Math.random() - 0.5) * 8, 3, 0, Math.PI * 2);
    ctx.stroke();
  } else if (trail === 'NEON_GHOST') {
    ctx.fillStyle = skin.glowColor || 'rgba(0, 255, 255, 0.3)';
    ctx.beginPath();
    ctx.arc(tx, ty, cellSize * 0.3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawPolygon(ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, sides: number) {
  ctx.beginPath();
  for (let i = 0; i < sides; i++) {
    const angle = (i * 2 * Math.PI) / sides;
    const px = x + radius * Math.cos(angle);
    const py = y + radius * Math.sin(angle);
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

function drawStar(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  spikes: number,
  outerRadius: number,
  innerRadius: number
) {
  let rot = (Math.PI / 2) * 3;
  let x = cx;
  let y = cy;
  const step = Math.PI / spikes;

  ctx.beginPath();
  ctx.moveTo(cx, cy - outerRadius);
  for (let i = 0; i < spikes; i++) {
    x = cx + Math.cos(rot) * outerRadius;
    y = cy + Math.sin(rot) * outerRadius;
    ctx.lineTo(x, y);
    rot += step;

    x = cx + Math.cos(rot) * innerRadius;
    y = cy + Math.sin(rot) * innerRadius;
    ctx.lineTo(x, y);
    rot += step;
  }
  ctx.lineTo(cx, cy - outerRadius);
  ctx.closePath();
}

function interpolateColor(color1: string, color2: string, factor: number): string {
  try {
    const c1 = hexToRgb(color1);
    const c2 = hexToRgb(color2);
    if (!c1 || !c2) return color1;

    const r = Math.round(c1.r + factor * (c2.r - c1.r));
    const g = Math.round(c1.g + factor * (c2.g - c1.g));
    const b = Math.round(c1.b + factor * (c2.b - c1.b));

    return `rgb(${r}, ${g}, ${b})`;
  } catch {
    return color1;
  }
}

function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : null;
}
