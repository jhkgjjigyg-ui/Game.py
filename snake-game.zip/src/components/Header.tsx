import React from 'react';
import { SnakeSkin } from '../types';
import { soundManager } from '../utils/audio';
import { Gamepad2, Palette, Sparkles, Trophy, Volume2, VolumeX } from 'lucide-react';

interface HeaderProps {
  activeTab: 'game' | 'gallery' | 'customizer' | 'leaderboard';
  onTabChange: (tab: 'game' | 'gallery' | 'customizer' | 'leaderboard') => void;
  equippedSkin: SnakeSkin;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  equippedSkin,
  isMuted,
  onToggleMute,
}) => {
  return (
    <header className="w-full bg-slate-900/90 border-b border-slate-800 sticky top-0 z-30 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Logo & Equipped Skin Pill */}
        <div className="flex items-center justify-between md:justify-start gap-3">
          <div
            onClick={() => onTabChange('game')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center text-slate-950 font-black text-xl shadow-lg group-hover:scale-105 transition">
              🐍
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight text-white group-hover:text-emerald-400 transition">
                SNAKE<span className="text-emerald-400 font-normal">CRAFT</span>
              </h1>
              <p className="text-[10px] text-slate-400 font-medium">Custom Skin Edition</p>
            </div>
          </div>

          {/* Equipped Skin Pill */}
          <div
            onClick={() => onTabChange('gallery')}
            className="flex items-center gap-2 bg-slate-950/80 hover:bg-slate-950 border border-slate-800 rounded-full px-3 py-1 cursor-pointer transition"
            title="Click to view skin wardrobe"
          >
            <span
              className="w-3 h-3 rounded-full shadow-sm"
              style={{ backgroundColor: equippedSkin.headColor }}
            />
            <span className="text-xs font-bold text-slate-200">{equippedSkin.name}</span>
            <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 px-1.5 py-0.2 rounded-full border border-emerald-500/20">
              Active
            </span>
          </div>
        </div>

        {/* Navigation Tabs & Sound Toggle */}
        <div className="flex items-center justify-between md:justify-end gap-2">
          <nav className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800 overflow-x-auto">
            {[
              { id: 'game', label: 'Play', icon: Gamepad2 },
              { id: 'gallery', label: 'Skin Gallery', icon: Palette },
              { id: 'customizer', label: 'Studio', icon: Sparkles },
              { id: 'leaderboard', label: 'Records', icon: Trophy },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    soundManager.playButtonClick();
                    onTabChange(tab.id as typeof activeTab);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-emerald-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </nav>

          {/* Sound Toggle */}
          <button
            onClick={onToggleMute}
            title={isMuted ? 'Unmute audio' : 'Mute audio'}
            className="p-2 bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 rounded-xl transition cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>
      </div>
    </header>
  );
};
