import React, { useState } from 'react';
import { SnakeSkin } from '../types';
import { SkinPreview } from './SkinPreview';
import { soundManager } from '../utils/audio';
import { Plus, Check, Trash2, Edit3, Search, Sparkles } from 'lucide-react';

interface SkinGalleryProps {
  skins: SnakeSkin[];
  selectedSkinId: string;
  onSelectSkin: (id: string) => void;
  onCreateNewSkin: () => void;
  onEditSkin: (skin: SnakeSkin) => void;
  onDeleteSkin: (id: string) => void;
}

export const SkinGallery: React.FC<SkinGalleryProps> = ({
  skins,
  selectedSkinId,
  onSelectSkin,
  onCreateNewSkin,
  onEditSkin,
  onDeleteSkin,
}) => {
  const [filter, setFilter] = useState<'all' | 'preset' | 'custom'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSkins = skins.filter((skin) => {
    if (filter === 'preset' && skin.isCustom) return false;
    if (filter === 'custom' && !skin.isCustom) return false;
    if (searchQuery.trim()) {
      return skin.name.toLowerCase().includes(searchQuery.toLowerCase().trim());
    }
    return true;
  });

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Top Banner & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-100 flex items-center gap-2">
            Snake Skin Wardrobe <Sparkles className="w-6 h-6 text-amber-400" />
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Choose from preset legendary skins or build your own custom skin!
          </p>
        </div>

        <button
          onClick={() => {
            soundManager.playButtonClick();
            onCreateNewSkin();
          }}
          className="px-5 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-slate-950 font-extrabold rounded-xl shadow-lg transition transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2 cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-5 h-5" /> Create Custom Skin
        </button>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 bg-slate-900/80 p-1 rounded-xl border border-slate-800 self-start">
          {[
            { id: 'all', label: `All Skins (${skins.length})` },
            { id: 'preset', label: 'Preset Legendary' },
            { id: 'custom', label: `My Custom (${skins.filter((s) => s.isCustom).length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                soundManager.playButtonClick();
                setFilter(tab.id as typeof filter);
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                filter === tab.id
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search skins..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
          />
        </div>
      </div>

      {/* Skins Grid */}
      {filteredSkins.length === 0 ? (
        <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-12 text-center">
          <div className="text-4xl mb-3">🎨</div>
          <h3 className="text-lg font-bold text-slate-300">No skins found</h3>
          <p className="text-slate-500 text-xs mt-1">Try a different search or create your custom skin now!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredSkins.map((skin) => {
            const isEquipped = skin.id === selectedSkinId;
            return (
              <div
                key={skin.id}
                className={`group bg-slate-900 border rounded-2xl p-4 flex flex-col justify-between transition-all duration-300 ${
                  isEquipped
                    ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-xl shadow-emerald-500/10'
                    : 'border-slate-800 hover:border-slate-700 hover:shadow-lg'
                }`}
              >
                <div>
                  {/* Top Header: Name & Badge */}
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-extrabold text-slate-100 text-base group-hover:text-emerald-400 transition">
                      {skin.name}
                    </h3>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        skin.isCustom
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {skin.isCustom ? 'Custom' : 'Preset'}
                    </span>
                  </div>

                  {/* Motion Skin Canvas */}
                  <div className="relative mb-3">
                    <SkinPreview
                      skin={skin}
                      width={280}
                      height={140}
                      animated={true}
                      className="w-full h-36"
                    />

                    {isEquipped && (
                      <div className="absolute top-2 right-2 bg-emerald-500 text-slate-950 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full shadow-md flex items-center gap-1">
                        <Check className="w-3 h-3" /> Equipped
                      </div>
                    )}
                  </div>

                  {/* Details Tags */}
                  <div className="flex flex-wrap gap-1.5 text-[10px] text-slate-400 font-medium mb-4">
                    <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {skin.pattern}
                    </span>
                    <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {skin.headStyle.replace('_', ' ')}
                    </span>
                    <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {skin.foodSkin || '🍎'}
                    </span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    onClick={() => {
                      soundManager.playSkinSelectSound();
                      onSelectSkin(skin.id);
                    }}
                    disabled={isEquipped}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                      isEquipped
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 cursor-default'
                        : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-md'
                    }`}
                  >
                    {isEquipped ? 'Currently Active' : 'Equip Skin'}
                  </button>

                  <button
                    onClick={() => {
                      soundManager.playButtonClick();
                      onEditSkin(skin);
                    }}
                    title="Customize or Duplicate"
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  {skin.isCustom && (
                    <button
                      onClick={() => {
                        if (confirm(`Delete custom skin "${skin.name}"?`)) {
                          soundManager.playButtonClick();
                          onDeleteSkin(skin.id);
                        }
                      }}
                      title="Delete Skin"
                      className="p-2 bg-slate-950 hover:bg-red-950 text-slate-500 hover:text-red-400 rounded-xl border border-slate-800 hover:border-red-900 transition cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
