import React, { useState } from 'react';
import {
  SnakeSkin,
  SnakePattern,
  HeadStyle,
  BodyShape,
  TrailEffect,
} from '../types';
import { SkinPreview } from './SkinPreview';
import { soundManager } from '../utils/audio';
import { PRESET_SKINS } from '../data/presetSkins';
import { Palette, Sparkles, Check, Eye, Crown, Layers, FastForward } from 'lucide-react';

interface SkinCustomizerProps {
  initialSkin?: SnakeSkin;
  onSave: (skin: SnakeSkin, equipNow: boolean) => void;
  onCancel?: () => void;
}

export const SkinCustomizer: React.FC<SkinCustomizerProps> = ({
  initialSkin,
  onSave,
  onCancel,
}) => {
  const [name, setName] = useState(initialSkin?.name || 'My Custom Snake');
  const [headColor, setHeadColor] = useState(initialSkin?.headColor || '#10B981');
  const [bodyStartColor, setBodyStartColor] = useState(initialSkin?.bodyStartColor || '#34D399');
  const [bodyEndColor, setBodyEndColor] = useState(initialSkin?.bodyEndColor || '#059669');
  const [borderColor, setBorderColor] = useState(initialSkin?.borderColor || '#064E3B');
  const [glowColor, setGlowColor] = useState(initialSkin?.glowColor || '#10B981');
  const [eyeColor, setEyeColor] = useState(initialSkin?.eyeColor || '#FFFFFF');

  const [pattern, setPattern] = useState<SnakePattern>(initialSkin?.pattern || 'GRADIENT');
  const [headStyle, setHeadStyle] = useState<HeadStyle>(initialSkin?.headStyle || 'CUTE_EYES');
  const [bodyShape, setBodyShape] = useState<BodyShape>(initialSkin?.bodyShape || 'ROUNDED');
  const [foodSkin, setFoodSkin] = useState<string>(initialSkin?.foodSkin || '🍎');
  const [trailEffect, setTrailEffect] = useState<TrailEffect>(initialSkin?.trailEffect || 'NONE');

  const [activeTab, setActiveTab] = useState<'colors' | 'pattern' | 'head' | 'shape' | 'food'>('colors');

  // Assembled Skin object
  const currentSkin: SnakeSkin = {
    id: initialSkin?.isCustom ? initialSkin.id : 'custom-' + Date.now(),
    name: name.trim() || 'Custom Snake',
    isCustom: true,
    headColor,
    bodyStartColor,
    bodyEndColor,
    borderColor,
    glowColor,
    eyeColor,
    pattern,
    headStyle,
    bodyShape,
    foodSkin,
    trailEffect,
    createdAt: initialSkin?.createdAt || Date.now(),
  };

  const applyPresetTemplate = (preset: SnakeSkin) => {
    soundManager.playButtonClick();
    setName(`${preset.name} Custom`);
    setHeadColor(preset.headColor);
    setBodyStartColor(preset.bodyStartColor);
    setBodyEndColor(preset.bodyEndColor);
    setBorderColor(preset.borderColor);
    setGlowColor(preset.glowColor || preset.headColor);
    setEyeColor(preset.eyeColor);
    setPattern(preset.pattern);
    setHeadStyle(preset.headStyle);
    setBodyShape(preset.bodyShape);
    setFoodSkin(preset.foodSkin);
    setTrailEffect(preset.trailEffect);
  };

  const handleSave = (equipNow: boolean) => {
    soundManager.playSkinSelectSound();
    onSave(currentSkin, equipNow);
  };

  const patternOptions: { value: SnakePattern; label: string; desc: string }[] = [
    { value: 'GRADIENT', label: 'Smooth Gradient', desc: 'Transitions smoothly from start to end color' },
    { value: 'SOLID', label: 'Solid Color', desc: 'Uniform body color across all segments' },
    { value: 'STRIPES', label: 'Alternating Stripes', desc: 'Alternating start and end colors' },
    { value: 'NEON', label: 'Neon Cyber', desc: 'Triple neon pulse segment color pattern' },
    { value: 'RAINBOW', label: 'Animated Rainbow', desc: 'Dynamic spectrum hue rotation' },
    { value: 'POLKA', label: 'Polka Dots', desc: 'Polka dot accents inside segments' },
    { value: 'SCALES', label: 'Reptile Scales', desc: 'Overlapping snake scale texture' },
    { value: 'CHECKER', label: 'Checkerboard', desc: 'High-contrast checker pattern' },
  ];

  const headStyleOptions: { value: HeadStyle; label: string; icon: string }[] = [
    { value: 'CLASSIC', label: 'Classic Eyes', icon: '👀' },
    { value: 'CUTE_EYES', label: 'Kawaii Anime', icon: '✨' },
    { value: 'CYBER_VISOR', label: 'Cyber Visor', icon: '🕶️' },
    { value: 'SUNGLASSES', label: 'Cool Shades', icon: '😎' },
    { value: 'CROWN', label: 'Royal Crown', icon: '👑' },
    { value: 'HORNS', label: 'Demon Horns', icon: '😈' },
    { value: 'CAT_EARS', label: 'Cat Ears', icon: '🐱' },
    { value: 'DRAGON', label: 'Dragon Spikes', icon: '🐉' },
    { value: 'SKELETON', label: 'Shadow Skull', icon: '💀' },
  ];

  const bodyShapeOptions: { value: BodyShape; label: string; icon: string }[] = [
    { value: 'ROUNDED', label: 'Smooth Pills', icon: '⚪' },
    { value: 'SQUARE', label: '8-Bit Pixel', icon: '⬛' },
    { value: 'HEXAGON', label: 'Cyber Hex', icon: '⬢' },
    { value: 'SPIKY', label: 'Spiky Star', icon: '⭐' },
  ];

  const foodOptions = ['🍎', '🍕', '💎', '🍩', '🍔', '⭐', '⚡', '🍦', '🍒', '🥩', '🍰', '🍉'];

  const trailOptions: { value: TrailEffect; label: string; icon: string }[] = [
    { value: 'NONE', label: 'No Trail', icon: '🚫' },
    { value: 'SPARKLES', label: 'Gold Sparkles', icon: '✨' },
    { value: 'FIRE', label: 'Inferno Flame', icon: '🔥' },
    { value: 'BUBBLES', label: 'Cyan Bubbles', icon: '🫧' },
    { value: 'NEON_GHOST', label: 'Neon Aura', icon: '🌌' },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-2xl text-slate-100">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-cyan-400 to-indigo-400">
            Skin Studio & Customizer
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm mt-1">
            Design your own custom snake with colors, patterns, accessories, and trails!
          </p>
        </div>

        {/* Quick presets */}
        <div className="flex items-center gap-2 overflow-x-auto py-1">
          <span className="text-xs text-slate-500 font-medium whitespace-nowrap">Presets:</span>
          {PRESET_SKINS.slice(0, 5).map((preset) => (
            <button
              key={preset.id}
              onClick={() => applyPresetTemplate(preset)}
              className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition cursor-pointer whitespace-nowrap"
            >
              {preset.name.split(' ')[0]}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Live Canvas Preview & Skin Name */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5" /> Live Motion Preview
              </span>
              <span className="text-xs text-slate-500 font-mono">100% Real-time</span>
            </div>

            <SkinPreview
              skin={currentSkin}
              width={340}
              height={180}
              animated={true}
              className="w-full h-44 border-slate-800"
            />
          </div>

          {/* Skin Name Input */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Skin Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter custom skin name..."
              maxLength={24}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-2 mt-auto">
            <button
              onClick={() => handleSave(true)}
              className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-slate-950 font-extrabold rounded-xl shadow-lg transition transform active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Check className="w-5 h-5" /> Save & Equip Now
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleSave(false)}
                className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition cursor-pointer"
              >
                Save to Gallery
              </button>

              {onCancel && (
                <button
                  onClick={onCancel}
                  className="py-2.5 bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-slate-200 text-xs font-semibold rounded-xl border border-slate-800 transition cursor-pointer"
                >
                  Cancel
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Customization Controls */}
        <div className="lg:col-span-7 flex flex-col bg-slate-950/70 p-4 rounded-xl border border-slate-800">
          {/* Controls Navigation Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-2 mb-4 border-b border-slate-800">
            {[
              { id: 'colors', label: 'Colors', icon: Palette },
              { id: 'pattern', label: 'Patterns', icon: Layers },
              { id: 'head', label: 'Head & Eyes', icon: Crown },
              { id: 'shape', label: 'Body & Trail', icon: Sparkles },
              { id: 'food', label: 'Food Skin', icon: FastForward },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    soundManager.playButtonClick();
                    setActiveTab(tab.id as typeof activeTab);
                  }}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* TAB 1: Colors */}
          {activeTab === 'colors' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-slate-300">Color Palette Builder</h3>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <ColorPickerCard
                  label="Snake Head"
                  color={headColor}
                  onChange={setHeadColor}
                />
                <ColorPickerCard
                  label="Body Start"
                  color={bodyStartColor}
                  onChange={setBodyStartColor}
                />
                <ColorPickerCard
                  label="Body End"
                  color={bodyEndColor}
                  onChange={setBodyEndColor}
                />
                <ColorPickerCard
                  label="Outline / Border"
                  color={borderColor}
                  onChange={setBorderColor}
                />
                <ColorPickerCard
                  label="Glow Aura"
                  color={glowColor}
                  onChange={setGlowColor}
                />
                <ColorPickerCard
                  label="Eyes / Pupil"
                  color={eyeColor}
                  onChange={setEyeColor}
                />
              </div>

              {/* Quick Swatches */}
              <div className="pt-3 border-t border-slate-800">
                <span className="text-xs text-slate-400 block mb-2 font-medium">Quick Color Schemes:</span>
                <div className="flex flex-wrap gap-2">
                  {[
                    { head: '#10B981', start: '#34D399', end: '#059669', border: '#064E3B', glow: '#10B981' },
                    { head: '#06B6D4', start: '#EC4899', end: '#3B82F6', border: '#00FFFF', glow: '#EC4899' },
                    { head: '#F59E0B', start: '#EF4444', end: '#8B5CF6', border: '#FFFFFF', glow: '#F43F5E' },
                    { head: '#FBBF24', start: '#F59E0B', end: '#D97706', border: '#78350F', glow: '#FCD34D' },
                    { head: '#F472B6', start: '#F472B6', end: '#FCE7F3', border: '#DB2777', glow: '#F472B6' },
                    { head: '#22C55E', start: '#16A34A', end: '#15803D', border: '#022C22', glow: '#4ADE80' },
                  ].map((s, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setHeadColor(s.head);
                        setBodyStartColor(s.start);
                        setBodyEndColor(s.end);
                        setBorderColor(s.border);
                        setGlowColor(s.glow);
                      }}
                      className="w-7 h-7 rounded-full border-2 border-slate-700 overflow-hidden relative transition transform hover:scale-110 cursor-pointer"
                      style={{ background: `linear-gradient(135deg, ${s.head}, ${s.start}, ${s.end})` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Patterns */}
          {activeTab === 'pattern' && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-300 mb-2">Body Texture Pattern</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {patternOptions.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => {
                      soundManager.playButtonClick();
                      setPattern(opt.value);
                    }}
                    className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                      pattern === opt.value
                        ? 'bg-emerald-500/15 border-emerald-500 text-slate-100'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-850 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold text-xs">{opt.label}</div>
                    <div className="text-[11px] opacity-75 mt-0.5">{opt.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: Head & Eyes */}
          {activeTab === 'head' && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-300 mb-2">Head Accessory & Eyes</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {headStyleOptions.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => {
                      soundManager.playButtonClick();
                      setHeadStyle(opt.value);
                    }}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition cursor-pointer ${
                      headStyle === opt.value
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <span className="text-2xl">{opt.icon}</span>
                    <span className="text-xs font-semibold">{opt.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: Body Shape & Trail */}
          {activeTab === 'shape' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-300 mb-2">Segment Body Shape</h3>
                <div className="grid grid-cols-2 gap-2">
                  {bodyShapeOptions.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => {
                        soundManager.playButtonClick();
                        setBodyShape(opt.value);
                      }}
                      className={`p-3 rounded-xl border flex items-center gap-2 transition cursor-pointer ${
                        bodyShape === opt.value
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <span className="text-lg">{opt.icon}</span>
                      <span className="text-xs font-semibold">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800">
                <h3 className="text-sm font-bold text-slate-300 mb-2">Tail Particle Trail</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {trailOptions.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => {
                        soundManager.playButtonClick();
                        setTrailEffect(opt.value);
                      }}
                      className={`p-2.5 rounded-xl border flex items-center gap-2 transition cursor-pointer ${
                        trailEffect === opt.value
                          ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <span>{opt.icon}</span>
                      <span className="text-xs font-semibold">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: Food Skin */}
          {activeTab === 'food' && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-300 mb-2">Favorite Food Texture</h3>
              <p className="text-xs text-slate-400 mb-3">
                Select what food your custom snake loves to hunt during gameplay!
              </p>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                {foodOptions.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => {
                      soundManager.playButtonClick();
                      setFoodSkin(emoji);
                    }}
                    className={`p-3 text-2xl rounded-xl border flex items-center justify-center transition cursor-pointer ${
                      foodSkin === emoji
                        ? 'bg-amber-500/20 border-amber-500 scale-110 shadow-lg'
                        : 'bg-slate-900 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

interface ColorPickerCardProps {
  label: string;
  color: string;
  onChange: (color: string) => void;
}

const ColorPickerCard: React.FC<ColorPickerCardProps> = ({ label, color, onChange }) => (
  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 flex flex-col gap-1.5">
    <span className="text-[11px] font-bold text-slate-400 truncate">{label}</span>
    <div className="flex items-center gap-2">
      <input
        type="color"
        value={color}
        onChange={(e) => onChange(e.target.value)}
        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0 p-0"
      />
      <span className="text-xs font-mono text-slate-300 uppercase">{color}</span>
    </div>
  </div>
);
