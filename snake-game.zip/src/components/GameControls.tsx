import React from 'react';
import { Direction, GameStatus, GameDifficulty, GameMode } from '../types';
import { soundManager } from '../utils/audio';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Pause, Play, RotateCcw, Settings2 } from 'lucide-react';

interface GameControlsProps {
  status: GameStatus;
  currentDirection: Direction;
  difficulty: GameDifficulty;
  gameMode: GameMode;
  onDirectionChange: (dir: Direction) => void;
  onPauseToggle: () => void;
  onRestart: () => void;
  onDifficultyChange: (diff: GameDifficulty) => void;
  onModeChange: (mode: GameMode) => void;
}

export const GameControls: React.FC<GameControlsProps> = ({
  status,
  currentDirection,
  difficulty,
  gameMode,
  onDirectionChange,
  onPauseToggle,
  onRestart,
  onDifficultyChange,
  onModeChange,
}) => {
  const handleDirClick = (dir: Direction) => {
    soundManager.playTurnSound();
    onDirectionChange(dir);
  };

  return (
    <div className="w-full max-w-xl mx-auto space-y-4">
      {/* Game Action Bar */}
      <div className="flex items-center justify-between gap-2 bg-slate-900 border border-slate-800 p-3 rounded-2xl">
        <div className="flex items-center gap-2">
          {status === 'PLAYING' && (
            <button
              onClick={onPauseToggle}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs transition flex items-center gap-1.5 cursor-pointer shadow"
            >
              <Pause className="w-4 h-4" /> Pause
            </button>
          )}

          {status === 'PAUSED' && (
            <button
              onClick={onPauseToggle}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs transition flex items-center gap-1.5 cursor-pointer shadow"
            >
              <Play className="w-4 h-4" /> Resume
            </button>
          )}

          {(status === 'PLAYING' || status === 'PAUSED' || status === 'GAMEOVER') && (
            <button
              onClick={onRestart}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Restart
            </button>
          )}
        </div>

        {/* Difficulty & Mode Selectors */}
        <div className="flex items-center gap-2">
          <select
            value={difficulty}
            onChange={(e) => onDifficultyChange(e.target.value as GameDifficulty)}
            disabled={status === 'PLAYING'}
            className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs font-semibold text-slate-200 focus:outline-none focus:border-emerald-500 transition cursor-pointer disabled:opacity-50"
          >
            <option value="EASY">Easy Speed</option>
            <option value="MEDIUM">Medium Speed</option>
            <option value="HARD">Hard Speed</option>
            <option value="INSANE">Insane Turbo</option>
          </select>

          <select
            value={gameMode}
            onChange={(e) => onModeChange(e.target.value as GameMode)}
            disabled={status === 'PLAYING'}
            className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs font-semibold text-slate-200 focus:outline-none focus:border-emerald-500 transition cursor-pointer disabled:opacity-50"
          >
            <option value="CLASSIC">Classic Mode</option>
            <option value="OBSTACLES">Obstacles Mode</option>
            <option value="NO_WALLS">Pass Through Walls</option>
          </select>
        </div>
      </div>

      {/* Touch D-Pad Controls */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col items-center">
        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-3">
          On-Screen / Touch D-Pad
        </div>

        <div className="grid grid-cols-3 gap-2 w-48 sm:w-56">
          <div />
          <button
            onClick={() => handleDirClick('UP')}
            disabled={currentDirection === 'DOWN'}
            className="h-12 bg-slate-800 hover:bg-emerald-500/20 active:bg-emerald-500/40 border border-slate-700 rounded-xl flex items-center justify-center text-slate-200 hover:text-emerald-400 disabled:opacity-30 transition cursor-pointer shadow-md"
          >
            <ArrowUp className="w-6 h-6" />
          </button>
          <div />

          <button
            onClick={() => handleDirClick('LEFT')}
            disabled={currentDirection === 'RIGHT'}
            className="h-12 bg-slate-800 hover:bg-emerald-500/20 active:bg-emerald-500/40 border border-slate-700 rounded-xl flex items-center justify-center text-slate-200 hover:text-emerald-400 disabled:opacity-30 transition cursor-pointer shadow-md"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>

          <button
            onClick={onPauseToggle}
            className="h-12 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-center text-xs font-bold text-slate-400 hover:text-slate-200 transition cursor-pointer"
          >
            {status === 'PLAYING' ? 'PAUSE' : 'PLAY'}
          </button>

          <button
            onClick={() => handleDirClick('RIGHT')}
            disabled={currentDirection === 'LEFT'}
            className="h-12 bg-slate-800 hover:bg-emerald-500/20 active:bg-emerald-500/40 border border-slate-700 rounded-xl flex items-center justify-center text-slate-200 hover:text-emerald-400 disabled:opacity-30 transition cursor-pointer shadow-md"
          >
            <ArrowRight className="w-6 h-6" />
          </button>

          <div />
          <button
            onClick={() => handleDirClick('DOWN')}
            disabled={currentDirection === 'UP'}
            className="h-12 bg-slate-800 hover:bg-emerald-500/20 active:bg-emerald-500/40 border border-slate-700 rounded-xl flex items-center justify-center text-slate-200 hover:text-emerald-400 disabled:opacity-30 transition cursor-pointer shadow-md"
          >
            <ArrowDown className="w-6 h-6" />
          </button>
          <div />
        </div>

        <div className="mt-3 text-[11px] text-slate-500 text-center">
          Keyboard shortcuts: <span className="text-slate-300 font-mono">WASD / Arrow Keys</span> • <span className="text-slate-300 font-mono">Space</span> to pause
        </div>
      </div>
    </div>
  );
};
