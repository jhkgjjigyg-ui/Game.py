import React from 'react';
import { SnakeSkin, GameDifficulty, GameMode } from '../types';
import { Trophy, Zap, Flame, ShieldAlert } from 'lucide-react';

interface ScoreBoardProps {
  score: number;
  highScore: number;
  foodEaten: number;
  combo: number;
  difficulty: GameDifficulty;
  gameMode: GameMode;
  skin: SnakeSkin;
}

export const ScoreBoard: React.FC<ScoreBoardProps> = ({
  score,
  highScore,
  foodEaten,
  combo,
  difficulty,
  gameMode,
  skin,
}) => {
  return (
    <div className="w-full max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-xl mb-4 text-slate-100">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
        {/* Score */}
        <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex flex-col justify-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Score</span>
          <span className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight">{score}</span>
        </div>

        {/* High Score */}
        <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex flex-col justify-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center justify-center gap-1">
            <Trophy className="w-3 h-3 text-amber-400" /> Best
          </span>
          <span className="text-xl sm:text-2xl font-black text-amber-400 tracking-tight">{highScore}</span>
        </div>

        {/* Combo */}
        <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex flex-col justify-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center justify-center gap-1">
            <Flame className="w-3 h-3 text-orange-500" /> Combo
          </span>
          <span
            className={`text-xl sm:text-2xl font-black transition ${
              combo > 1 ? 'text-orange-400 animate-pulse' : 'text-slate-400'
            }`}
          >
            x{combo}
          </span>
        </div>

        {/* Food Eaten & Skin */}
        <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 flex flex-col justify-center">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Food</span>
          <span className="text-xl sm:text-2xl font-black text-cyan-400 flex items-center justify-center gap-1">
            <span>{skin.foodSkin || '🍎'}</span>
            <span>{foodEaten}</span>
          </span>
        </div>
      </div>

      {/* Mode & Skin Info Bar */}
      <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 px-1">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-300">Skin:</span>
          <span className="text-emerald-400 font-bold flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 rounded-full" style={{ backgroundColor: skin.headColor }} />
            {skin.name}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-medium">
            {difficulty}
          </span>
          {gameMode !== 'CLASSIC' && (
            <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30 flex items-center gap-1">
              <ShieldAlert className="w-3 h-3" /> {gameMode}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
