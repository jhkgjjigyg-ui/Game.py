import { SnakeSkin, HighScoreEntry } from '../types';
import { PRESET_SKINS } from '../data/presetSkins';

const CUSTOM_SKINS_KEY = 'snake_custom_skins';
const SELECTED_SKIN_KEY = 'snake_selected_skin_id';
const HIGH_SCORES_KEY = 'snake_high_scores';

export function getCustomSkins(): SnakeSkin[] {
  try {
    const raw = localStorage.getItem(CUSTOM_SKINS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function getAllSkins(): SnakeSkin[] {
  const customSkins = getCustomSkins();
  return [...PRESET_SKINS, ...customSkins];
}

export function saveCustomSkin(skin: SnakeSkin): SnakeSkin[] {
  const existing = getCustomSkins();
  const index = existing.findIndex((s) => s.id === skin.id);

  let updated: SnakeSkin[];
  if (index >= 0) {
    updated = [...existing];
    updated[index] = skin;
  } else {
    updated = [skin, ...existing];
  }

  try {
    localStorage.setItem(CUSTOM_SKINS_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Error saving custom skin:', err);
  }

  return updated;
}

export function deleteCustomSkin(id: string): SnakeSkin[] {
  const existing = getCustomSkins();
  const updated = existing.filter((s) => s.id !== id);

  try {
    localStorage.setItem(CUSTOM_SKINS_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Error deleting custom skin:', err);
  }

  // If deleted skin was selected, fallback to default emerald preset
  if (getSelectedSkinId() === id) {
    setSelectedSkinId(PRESET_SKINS[0].id);
  }

  return updated;
}

export function getSelectedSkinId(): string {
  try {
    const id = localStorage.getItem(SELECTED_SKIN_KEY);
    if (id) {
      // Verify skin exists
      const all = getAllSkins();
      if (all.some((s) => s.id === id)) {
        return id;
      }
    }
  } catch {
    // Fallback
  }
  return PRESET_SKINS[0].id;
}

export function setSelectedSkinId(id: string): void {
  try {
    localStorage.setItem(SELECTED_SKIN_KEY, id);
  } catch (err) {
    console.error('Error setting selected skin:', err);
  }
}

export function getSelectedSkin(): SnakeSkin {
  const id = getSelectedSkinId();
  const all = getAllSkins();
  const found = all.find((s) => s.id === id);
  return found || PRESET_SKINS[0];
}

export function getHighScores(): HighScoreEntry[] {
  try {
    const raw = localStorage.getItem(HIGH_SCORES_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveHighScore(entry: Omit<HighScoreEntry, 'id'>): HighScoreEntry[] {
  const existing = getHighScores();
  const newEntry: HighScoreEntry = {
    ...entry,
    id: 'hs-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
  };

  const updated = [...existing, newEntry]
    .sort((a, b) => b.score - a.score)
    .slice(0, 10); // Keep top 10

  try {
    localStorage.setItem(HIGH_SCORES_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Error saving high score:', err);
  }

  return updated;
}
