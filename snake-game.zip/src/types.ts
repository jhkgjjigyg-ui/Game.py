export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export type GameStatus = 'IDLE' | 'PLAYING' | 'PAUSED' | 'GAMEOVER';

export type GameDifficulty = 'EASY' | 'MEDIUM' | 'HARD' | 'INSANE';

export type GameMode = 'CLASSIC' | 'OBSTACLES' | 'SPEEDUP' | 'NO_WALLS';

export type FoodType = 'REGULAR' | 'GOLDEN' | 'SPEED_BOOST' | 'SHRINK' | 'SCORE_MULTIPLIER';

export type SnakePattern = 
  | 'SOLID' 
  | 'STRIPES' 
  | 'GRADIENT' 
  | 'POLKA' 
  | 'NEON' 
  | 'RAINBOW' 
  | 'SCALES' 
  | 'CHECKER';

export type HeadStyle = 
  | 'CLASSIC' 
  | 'CUTE_EYES' 
  | 'CYBER_VISOR' 
  | 'SUNGLASSES' 
  | 'CROWN' 
  | 'HORNS' 
  | 'CAT_EARS' 
  | 'DRAGON' 
  | 'SKELETON';

export type BodyShape = 
  | 'ROUNDED' 
  | 'SQUARE' 
  | 'HEXAGON' 
  | 'CIRCLES' 
  | 'SPIKY';

export type TrailEffect = 
  | 'NONE' 
  | 'SPARKLES' 
  | 'FIRE' 
  | 'BUBBLES' 
  | 'NEON_GHOST';

export interface SnakeSkin {
  id: string;
  name: string;
  isCustom: boolean;
  headColor: string;
  bodyStartColor: string;
  bodyEndColor: string;
  borderColor: string;
  glowColor?: string;
  eyeColor: string;
  pattern: SnakePattern;
  headStyle: HeadStyle;
  bodyShape: BodyShape;
  foodSkin: string; // Emoji like '🍎', '🍕', '💎', '🍩'
  trailEffect: TrailEffect;
  createdAt?: number;
}

export interface Position {
  x: number;
  y: number;
}

export interface FoodItem {
  x: number;
  y: number;
  type: FoodType;
  emoji: string;
  points: number;
  duration?: number; // duration in ms before disappearing if special
  spawnTime?: number;
}

export interface Obstacle {
  x: number;
  y: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
}

export interface HighScoreEntry {
  id: string;
  score: number;
  date: string;
  skinName: string;
  difficulty: GameDifficulty;
  mode: GameMode;
  foodEaten: number;
}

export interface GameStats {
  score: number;
  highScore: number;
  foodEaten: number;
  combo: number;
  maxCombo: number;
  level: number;
}

export interface SoundSettings {
  muted: boolean;
  volume: number; // 0 to 1
}
